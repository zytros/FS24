1. install libraries in requirements.txt
2. run code
